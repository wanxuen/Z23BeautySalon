<?php
	session_start();
	
	//Destroy the session as the user successfully checked out
	session_destroy();
?>
<html>
<head>
    <title>Thank you!</title>
	<link rel="stylesheet" href="../style/webstyles.css">
</head>
<body class="post-body">
	<div class="order-details">
        <svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.133 12.632v-1.8a5.406 5.406 0 0 0-4.154-5.262.955.955 0 0 0 .021-.106V3.1a1 1 0 0 0-2 0v2.364a.955.955 0 0 0 .021.106 5.406 5.406 0 0 0-4.154 5.262v1.8C6.867 15.018 5 15.614 5 16.807 5 17.4 5 18 5.538 18h12.924C19 18 19 17.4 19 16.807c0-1.193-1.867-1.789-1.867-4.175ZM6 6a1 1 0 0 1-.707-.293l-1-1a1 1 0 0 1 1.414-1.414l1 1A1 1 0 0 1 6 6Zm-2 4H3a1 1 0 0 1 0-2h1a1 1 0 1 1 0 2Zm14-4a1 1 0 0 1-.707-1.707l1-1a1 1 0 1 1 1.414 1.414l-1 1A1 1 0 0 1 18 6Zm3 4h-1a1 1 0 1 1 0-2h1a1 1 0 1 1 0 2ZM8.823 19a3.453 3.453 0 0 0 6.354 0H8.823Z"/>
        </svg>
        <h2>Thank you for choosing us!</h2>
        <p>Your order has been confirmed. Kindly check your mail box that we had drop a confirmation email to you.</p>
        <button id="return">Return to Homepage</button>
    </div>
	
<script>
    document.getElementById("return").onclick = function() {
        window.location.href = "../index.php";
    };
</script>

</body>
</html>
