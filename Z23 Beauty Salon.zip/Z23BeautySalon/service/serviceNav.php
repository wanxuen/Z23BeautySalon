<nav id="serviceNav">
	<hr>
    <a href="../service/">All Services</a>
    |
	<a href="../service/serviceHair">Hair</a>
	|
	<a href="../service/serviceFacial">Facial</a>
	|
	<a href="../service/serviceMAP">Manicures and Pedicures</a>
	|
	<a href="../service/serviceMassage">Massage</a>
	<hr>
</nav>