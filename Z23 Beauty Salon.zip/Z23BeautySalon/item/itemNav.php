<nav id="itemNav">
	<hr>
    <a href="../item/">All Products</a>
    |
	<a href="../item/itemHair">Hair</a>
	|
	<a href="../item/itemNail">Nail Tool</a>
	|
	<a href="../item/itemFacial">Facial</a>
	<hr>
</nav>