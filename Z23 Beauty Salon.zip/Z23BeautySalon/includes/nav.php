<nav id="topNavigation">
	<hr>
	<a href="/Z23BeautySalon">Home</a>
	|
	<a href="/Z23BeautySalon/service/">Services</a>
	|
	<a href="/Z23BeautySalon/item/">Products</a>
	|
	<a href="/Z23BeautySalon/wishlist/">Wishlist</a>
	|
	<a href="/Z23BeautySalon/contactus">Contact Us</a>
	<hr>
</nav>
