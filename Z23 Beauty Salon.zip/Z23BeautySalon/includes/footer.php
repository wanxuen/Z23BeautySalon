<footer id = "pageFooter">
	<br><hr>
	&copy; 2001 Z23 Beauty Salon. All rights reserved.
</footer> 