<header id = "pageHeader">
	<img src="/Z23BeautySalon/photos/logo.png" width="100" height="100">
	<h1>Z23 Beauty Salon</h1>
</header>